function toolbox_prompt_info() {
  [[ -f /run/.toolboxenv ]] && echo "⬢"
}

alias tbe="toolbox enter"
alias tbr="toolbox run"
