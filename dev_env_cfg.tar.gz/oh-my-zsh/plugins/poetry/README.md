# Poetry Plugin

This plugin automatically installs [Poetry](https://python-poetry.org/)'s completions for you, and keeps them up to date as your Poetry version changes.

To use it, add `poetry` to the plugins array in your zshrc file:

```zsh
plugins=(... poetry)
```
